package dev4me.loginUser.controller;

import dev4me.loginUser.entidades.Usuario;
import dev4me.loginUser.entidades.UsuarioEmpresa;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/empresas")
public class EmpresaController {

    private List<UsuarioEmpresa> usuarios = new ArrayList<>();

    // Cadastra Usuario empresa
    @PostMapping
    public String cadastraUsuario (@RequestBody UsuarioEmpresa novoUsuarioEmpresa) {
        usuarios.add(novoUsuarioEmpresa);
        return String.format("Usuário %s cadastrado com sucesso", novoUsuarioEmpresa.getNomeContratante());
    }

    // Autenticar usuario empresa
    @PostMapping("/autenticacao")
    public String autenticaUsuario(@RequestBody UsuarioEmpresa autenticado) {
        for (UsuarioEmpresa user : usuarios) {
            if (user.getUsuario().equals(autenticado.getUsuario())) {
                if (user.getSenha().equals(autenticado.getSenha())) {
                    user.setAutenticado(true);
                    return String.format("Usuário %s agora está autenticado.", user.getNomeContratante());
                }
            }
        }
        return String.format("Usuário %s não encontrado.", autenticado.getNomeContratante());
    }

    // Deslogar usuario empresa
    @DeleteMapping("/deslogar")
    public String deslogaUsuario(@RequestBody UsuarioEmpresa desloga) {
        for (UsuarioEmpresa user : usuarios) {
            if (user.getUsuario().equals(desloga.getUsuario())) {
                if (user.getAutenticado()) {
                    user.setAutenticado(false);
                    return String.format("Logoff do usuário %s concluído", user.getNomeContratante());
                }
                return String.format("Usuário %s NÃO está autenticado", user.getNomeContratante());
            }
        }
        return String.format("Usuário %s não encontrado", desloga.getNomeContratante());
    }

    // Retorna todos os usuarios empresa
    @GetMapping
    public List<UsuarioEmpresa> getUsuarios() { return usuarios; }

    // Retorna somente autenticados
    @GetMapping("/autenticados")
    public List<UsuarioEmpresa> getAutenticados() {
        List<UsuarioEmpresa> autenticados = new ArrayList<>();

        for (UsuarioEmpresa user : usuarios) {
            if (user.getAutenticado()) {
                autenticados.add(user);
            }
        }
        return autenticados;
    }

}
