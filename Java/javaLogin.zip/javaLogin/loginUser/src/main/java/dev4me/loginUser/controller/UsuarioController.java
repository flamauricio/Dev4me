package dev4me.loginUser.controller;

import dev4me.loginUser.entidades.Usuario;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    private List<Usuario> usuarios = new ArrayList<>();

    // Cadastra Usuario
    @PostMapping
    public String cadastraUsuario (@RequestBody Usuario novoUsuario) {
        usuarios.add(novoUsuario);
        return String.format("Usuário %s cadastrado com sucesso", novoUsuario.getNome());
    }

    // Autentica o usuario
    @PostMapping("/autenticacao")
    public String autenticaUsuario(@RequestBody Usuario autenticado) {
        for (Usuario user : usuarios) {
            if (user.getUsuario().equals(autenticado.getUsuario())) {
                if (user.getSenha().equals(autenticado.getSenha())) {
                    user.setAutenticado(true);
                    return String.format("Usuário %s agora está autenticado.", user.getNome());
                }
            }
        }
        return String.format("Usuário %s não encontrado.", autenticado.getNome());
    }

    // Desloga o usuario da conta
    @DeleteMapping("/deslogar")
    public String deslogaUsuario(@RequestBody Usuario desloga) {
        for (Usuario user : usuarios) {
            if (user.getUsuario().equals(desloga.getUsuario())) {
                if (user.getAutenticado()) {
                    user.setAutenticado(false);
                    return String.format("Logoff do usuário %s concluído", user.getNome());
                }
                return String.format("Usuário %s NÃO está autenticado", user.getNome());
            }
        }
        return String.format("Usuário %s não encontrado", desloga.getNome());
    }

    // Retorna todos os Usuarios
    @GetMapping
    public List<Usuario> getUsuarios() { return usuarios; }

    // Retorna todos os Autenticados
    @GetMapping("/autenticados")
    public List<Usuario> getAutenticados() {
        List<Usuario> autenticados = new ArrayList<>();

        for (Usuario user : usuarios) {
            if (user.getAutenticado()) {
                autenticados.add(user);
            }
        }
        return autenticados;
    }

}
