package dev4me.loginUser.entidades;

public class UsuarioEmpresa {

    private String usuario;
    private String empresa;
    private String senha;
    private String nomeContratante;
    private Boolean autenticado = false;

    public Boolean getAutenticado() {
        return autenticado;
    }

    public void setAutenticado(Boolean autenticado) {
        this.autenticado = autenticado;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getSenha() {
        return senha;
    }

    public String getEmpresa() { return empresa; }

    public String getNomeContratante() { return nomeContratante; }
}
