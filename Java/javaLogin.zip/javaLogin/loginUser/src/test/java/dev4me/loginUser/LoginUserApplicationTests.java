package dev4me.loginUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
