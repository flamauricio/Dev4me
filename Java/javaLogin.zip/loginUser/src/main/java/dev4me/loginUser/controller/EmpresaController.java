package dev4me.loginUser.controller;

import dev4me.loginUser.entidades.Usuario;
import dev4me.loginUser.entidades.UsuarioEmpresa;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/empresas")
public class EmpresaController {

    private List<UsuarioEmpresa> usuarios = new ArrayList<>();

    @PostMapping
    public String cadastraUsuario (@RequestBody UsuarioEmpresa novoUsuarioEmpresa) {
        usuarios.add(novoUsuarioEmpresa);
        return String.format("Usuário %s cadastrado com sucesso", novoUsuarioEmpresa.getNomeContratante());
    }

    @PostMapping("/autenticacao/{usuario}/{senha}")
    public String autenticaUsuario(@PathVariable String usuario, @PathVariable String senha) {
        for (UsuarioEmpresa user : usuarios) {
            if (user.getUsuario().equals(usuario)) {
                if (user.pegaSenha().equals(senha)) {
                    user.setAutenticado(true);
                    return String.format("Usuário %s agora está autenticado.", user.getNomeContratante());
                }
            }
        }
        return String.format("Usuário %s não encontrado.", usuario);
    }

    @DeleteMapping("/autenticacao/{usuario}")
    public String deslogaUsuario(@PathVariable String usuario) {
        for (UsuarioEmpresa user : usuarios) {
            if (user.getUsuario().equals(usuario)) {
                if (user.getAutenticado()) {
                    user.setAutenticado(false);
                    return String.format("Logoff do usuário %s concluído", user.getNomeContratante());
                }
                return String.format("Usuário %s NÃO está autenticado", user.getNomeContratante());
            }
        }
        return String.format("Usuário %s não encontrado", usuario);
    }

    @GetMapping
    public List<UsuarioEmpresa> getUsuarios() { return usuarios; }

    @GetMapping("/autenticados")
    public List<UsuarioEmpresa> getAutenticados() {
        List<UsuarioEmpresa> autenticados = new ArrayList<>();

        for (UsuarioEmpresa user : usuarios) {
            if (user.getAutenticado()) {
                autenticados.add(user);
            }
        }
        return autenticados;
    }

}
