package dev4me.loginUser.controller;

import dev4me.loginUser.entidades.Usuario;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    private List<Usuario> usuarios = new ArrayList<>();

    @PostMapping
    public String cadastraUsuario (@RequestBody Usuario novoUsuario) {
        usuarios.add(novoUsuario);
        return String.format("Usuário %s cadastrado com sucesso", novoUsuario.getNome());
    }

    @PostMapping("/autenticacao/{usuario}/{senha}")
    public String autenticaUsuario(@PathVariable String usuario, @PathVariable String senha) {
        for (Usuario user : usuarios) {
            if (user.getUsuario().equals(usuario)) {
                if (user.pegaSenha().equals(senha)) {
                    user.setAutenticado(true);
                    return String.format("Usuário %s agora está autenticado.", user.getNome());
                }
            }
        }
        return String.format("Usuário %s não encontrado.", usuario);
    }

    @DeleteMapping("/autenticacao/{usuario}")
    public String deslogaUsuario(@PathVariable String usuario) {
        for (Usuario user : usuarios) {
            if (user.getUsuario().equals(usuario)) {
                if (user.getAutenticado()) {
                    user.setAutenticado(false);
                    return String.format("Logoff do usuário %s concluído", user.getNome());
                }
                return String.format("Usuário %s NÃO está autenticado", user.getNome());
            }
        }
        return String.format("Usuário %s não encontrado", usuario);
    }

    @GetMapping
    public List<Usuario> getUsuarios() { return usuarios; }

    @GetMapping("/autenticados")
    public List<Usuario> getAutenticados() {
        List<Usuario> autenticados = new ArrayList<>();

        for (Usuario user : usuarios) {
            if (user.getAutenticado()) {
                autenticados.add(user);
            }
        }
        return autenticados;
    }

}
